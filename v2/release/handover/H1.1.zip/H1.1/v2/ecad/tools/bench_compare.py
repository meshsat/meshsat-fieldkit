#!/usr/bin/env python3
"""bench_compare: grade a routed board's metrics against the baseline (Freerouting quality programme, Stage 1).

Gates first: any hard violation or open connection makes the run INELIGIBLE for quality ranking (it is recorded, never ranked); a differential
pair over 1 mm is a REGRESSION when the baseline board has fewer such pairs (the released boards carry their own: E4 one, A21 one, B14 nine before matching); router vias or total length up by more than 5 percent is a REGRESSION. Otherwise MET, with
  Q = 0.5 x (router vias / baseline router vias) + 0.3 x (length / baseline length) + 0.2 x (segments / baseline segments)
lower is better, 1.0 is the released board. Time is printed beside Q and never folded into it.
Usage: bench_compare.py <baseline.json> <metrics.json> [--board KEY] [--json out]   (KEY defaults to the metrics' tag, then its board stem)"""
import sys, json, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import hardset
NHARD = len(hardset.HARD_POST)   # the hard set a row must have been judged under to rank (15 September 2026)

# 10 September 2026 (both red teams, C3): the baseline was keyed by PHASE, so every C6 and B15 experiment looked its key up,
# found C5 and B14, and graded UNMEASURABLE after the route had been paid for: 66 of the 81 measured router hours. A baseline
# belongs to a BOARD, not to a phase of it; a phase that changes the board's metrics is exactly what the comparison measures.
BOARD_KEY = {"pcb-a-power": "A", "pcb-b-compute": "B", "pcb-c-display": "C", "pcb-c-ring": "CRING", "pcb-d-aprs": "D",
             "pcb-e1-dock": "E", "pcb-e2-rfjunction": "E2", "pcb-e5-block": "E5", "pcb-p-pack": "P"}


def board_key(stem):
    """The baseline key of a board file, project directory or stem: 'pcb-b-compute-b19/pcb-b-compute.kicad_pcb' -> 'B'."""
    base = os.path.basename(str(stem)); base = os.path.splitext(base)[0]
    for k, v in BOARD_KEY.items():
        if base == k or base.startswith(k + "-") or base.startswith(k + "."): return v
    return base

def arg(name, default=None): return sys.argv[sys.argv.index(name) + 1] if name in sys.argv else default

def compare(base, m):
    if m.get("hard") is None or m.get("unrouted") is None: return "UNMEASURABLE", "no DRC numbers in the metrics", None
    # A row judged under fewer hard types than today's set is not comparable with one judged under all of them: it
    # is quarantined here, never ranked, never promoted (15 September 2026, red team report 1 P0/P1: every stored
    # baseline and all 233 metric rows were six-type, and the report's asterisk was disclosure, not a gate).
    if int(m.get("hard_types_checked", 0) or 0) < NHARD: return "INELIGIBLE", "judged under %d hard types where the current set has %d: quarantined, regenerate the row" % (int(m.get("hard_types_checked", 0) or 0), NHARD), None
    if m["hard"] > 0 or m["unrouted"] > 0: return "INELIGIBLE", "hard %d (over %d types), unrouted %d of %d connections" % (m["hard"], m["hard_types_checked"], m["unrouted"], m["connections"]), None
    if m.get("pairs_over_1mm", 0) > base.get("pairs_over_1mm", 0): return "REGRESSION", "%d differential pairs over 1 mm (baseline %d)" % (m["pairs_over_1mm"], base.get("pairs_over_1mm", 0)), None
    bv, bl, bs = max(1, base["vias_router"]), max(1e-9, base["length_mm"]), max(1, base["tracks"])
    rv, rl, rs = m["vias_router"] / bv, m["length_mm"] / bl, m["tracks"] / bs
    q = round(0.5 * rv + 0.3 * rl + 0.2 * rs, 4)
    note = "router vias %d vs %d (%+.1f%%), length %.0f vs %.0f mm (%+.1f%%), segments %d vs %d (%+.1f%%), Q %.3f, time %.0f s vs %.0f s" % (
        m["vias_router"], base["vias_router"], (rv - 1) * 100, m["length_mm"], base["length_mm"], (rl - 1) * 100, m["tracks"], base["tracks"], (rs - 1) * 100, q, m.get("wall_seconds", 0), base.get("wall_seconds", 0))
    if rv > 1.05 or rl > 1.05: return "REGRESSION", note, q
    return "MET", note, q

def main():
    base_all = json.load(open(sys.argv[1])); m = json.load(open(sys.argv[2]))
    key = arg("--board") or board_key(m["board"])
    base = base_all.get(key)   # no prefix fallback: it could never match C6 to C5 and it hid the miss (10 Sep 2026)
    if base is None: print("UNMEASURABLE: no baseline for", key, "in", sys.argv[1], "- keys:", ", ".join(sorted(base_all))); sys.exit(3)
    verdict, note, q = compare(base, m)
    res = {"board": key, "verdict": verdict, "Q": q, "note": note, "baseline_tag": base.get("tag")}
    if arg("--json"): json.dump(res, open(arg("--json"), "w"), indent=1)
    print("%s %s: %s" % (verdict, key, note)); sys.exit(0 if verdict == "MET" else 1)

if __name__ == "__main__":
    if len(sys.argv) < 3: print(__doc__); sys.exit(2)
    main()
