# TOPOLOGY: two separately protected packs at the system node (Option A(i), stream a1elec, MESHSAT-1357)

**Second issue of the charger rows (stream s119, S-119, 29 September 2026).** The energy chain now carries board A's charger U3 at 0.979 (bracket 0.972 to 0.983; was 0.98, read from SLUSE66A Figure 8-4), with the FETs of decision 57, and Option A(i)'s lid charger U3B at 0.972 (bracket 0.963 to 0.978; was 0.975, read from Figure 8-3) on U3's 400 kHz row, which a session decision draws for it (the FET pair of decision 57, XAL1010-472ME, R16B 10 mOhm, IIN_HOST 6.2 A; `records/s119/apply_decision_s119.py`), weighted by energy over the model's own hours. Both are TI's loss equations (SLUSE66A Equations 6 to 22, printed pages 86 to 88) with the sense resistors inside each figure and the inductors' core loss excluded, so each is high by it (`records/s117/efficiency.out` section 7, `records/s119/u3b_hourly.out`). The chain's scripts were re-issued with their pins moved and every output regenerated (`records/s119/README.md`, `records/s119/headline_diff.out`). Where this page quotes a figure listed here, the page's figure is the first issue's and is superseded by the one given here. Model results on the September reference day; nothing is measured. **In this page, the two-pack model (`energy_two_pack.out`, second issue):** the design case (E2, lid at 13.23 C) keeps 30.3 Wh in the base and 0.7 Wh in the lid, **31.0 Wh together (was 31.1)**, down to a lid at +9.6 C (unchanged); the aggregate 4S18P 90.9 Wh (was 91.0); the base at +15 C as well 9.6 Wh (was 9.7). The entry requirement: at least **5.57 A (115.4 W)** into U3 held at the limit's minimum (was 5.56 A, 115.1 W) and 5.83 A (120.6 W) for the full 31.0 Wh (was 5.81 A, 120.3 W, 31.1 Wh). As generated (E1, U3 at 4.15 A): NOT MET, 377.2 Wh unserved, stops at hours 44 and 32 (was 374.5 Wh); the front end at its limits: 4.3 A 332.2 Wh unserved (was 329.4), 5.0 A 122.4 Wh (was 119.1), 5.7 A MEETS with 17.1 Wh (was 18.6); E1 with 650 and 800 Wp 225.9 and 187.2 Wh unserved (were 222.8 and 184.1). At E2's busiest hour U3 loses 2.7 W at 0.979 (was 2.6 W at 0.98) and U3B 1.5 W at 0.972 on 55.2 W in (was 1.4 W at 0.975 on 55.3 W), each with its sense resistors inside, so board A's charging peak is about **13.9 W** (was about 14.2 W, which counted R16, R17, R16B and R17B twice); over 72 h U3B loses 25.1 to 35.6 Wh (was 22.3 to 31.7) and the charge loop, now 23 mOhm without U3B's RSR, 4.7 to 6.7 Wh (was 5.7 to 8.2). U3's L2 is drawn as 4.7 uH XAL1010-472ME at 400 kHz (decision 56): 2.31 A p-p ripple and a 9.82 A peak at that hour (the first issue's 3.3 uH figures describe the inductor board A no longer draws). **U3B** is drawn on U3's 400 kHz row by the session decision of `records/s119/apply_decision_s119.py` (TOPOLOGY.md 3b and CHARGER.md 2 carry it as their second issue): Q7B and Q9B CSD17578Q5A, Q8B and Q10B CSD17577Q5A, L2B XAL1010-472ME, 191 k, R16B 10 mOhm, IIN_HOST 6.2 A; REGN 32.6 mA at the makers' maxima against its 50 mA minimum limit; with the first-drafted CSD18510Q5B U3B read 0.802 and ratio C of both lid options was NOT MET (`records/s119/reconcile_s119.out` section 4).

29 September 2026. **Prototype design, AI review: nothing drawn in a generator, built, ordered or measured.** This
page is the electrical design the energy model (`energy_two_pack.py`) runs, written for the generators' owners as a
DRAFT. Figures marked `.out` are printed by that script (`energy_two_pack.out`, section named); makers' figures carry
their document, section and page; ESTIMATE marks arithmetic on stated assumptions. M1 and REQ-072 are unchanged;
REQ-072 stays FAIL until this is drawn, reviewed and tested. Nothing here is purchased or authorised.

## 1. The answer in brief

```
 base 4S6P (both base pockets, section 8 of the energy record)       lid 4S12P (lid module)
 board P  (BQ4050 U1, BQ7720700 U2 + U2B, F1 25 A, F2 SCF9550,       board PL = board P as generated, a second instance
           Q1/Q2 CSD17570Q5B, R10 2 mOhm)                                      (its own image: GAUGE.md, k = 2)
      |  CELL+ (dock pins, as today)                                     |  hinge harness: 2 x 12 AWG + SMBus lead
      F1 (board A, 25 A MINI) -- CELL_FUSED                              F_LA (board A, 15 A MINI) -- LID_IN
      |                                                                  |                                  \
      R17 5 mOhm (U3's RSR)                          LM74700-Q1 + CSD18510Q5B (ideal diode, blocks node->lid)  \
      |                                                                  |                                   R17B 5 mOhm (U3B's RSR)
 ==== VBAT, the system node (U3's VSYS; every converter) ====  <------  LM5069-2 + CSD18510Q5B, 5.6 mOhm     |
      ^                    |                                             (current limit 8.7 to 11.0 A; UVLO    U3B BQ25731 buck-boost
      |                    +--- VBUS of U3B (a second BQ25731) --------  enable, off while U3B runs)          (VBAT in, lid out)
 U3 BQ25731 (from VBUS20, as generated)
```

1. **The base pack stays exactly where S-04 put it**: the one BQ25731 **U3** charges it through **R17** (its RSR) and it
   discharges through R17 into VBAT. Nothing in that path changes (section 2).
2. **The lid pack has its own charger and its own one-way discharge path.** A second BQ25731, **U3B**, takes its input
   from VBAT and charges the lid through its own RSR **R17B**; the lid discharges into VBAT through an **LM74700-Q1 ideal
   diode in series with an LM5069-2 current-limited switch** (section 3).
3. **What stops one pack charging the other** (section 3c; every statement here is about a fault-free path, the
   single faults that defeat it are in section 6 and go to the qualified battery review): base to lid is blocked in
   hardware (the ideal diode, and U3B's four-switch stage when off); lid to base happens only when the lid's voltage is
   above the base's, is limited in hardware to at most 11.0 A (1.83 A a base cell, under the cell's 2.0 A maximum charge), and is kept under 2.5 A in
   service by the host's join rule (0.20 V). The lid's discharge path is held off in hardware while U3B charges, so
   U3B's output can never flow back into the node through it (3b).
4. **The host sees two gauges on two separate SMBus segments** and **two chargers on the kit bus, U3B behind a
   TCA9543A switch** because both BQ25731 answer only at 0x6B (section 5).
5. **On the model**, this topology meets M1's September reference day with 400 Wp into a 200 W stage and board A's entry
   re-rated as drafted (E2), with the lid at the mean day's minimum air (13.23 C) and down to a lid at **+9.6 C**; the
   lowest points are 30.3 Wh in the base and 0.7 Wh in the lid (`.out` 3). The lid's 0.7 Wh is its floor, not a
   margin: the kit's margin is the base's 30.3 Wh. With board A's entry as generated it does not (section 7).

## 2. The base pack: unchanged, with section 8's additions

The base is the 4S6P of `records/energy/ENERGY-RECONCILIATION.md` section 8: the east and west 4S3P blocks joined at
every series node under the one board P, with U2B on the west block's own taps, a fuse per string and per middle link,
two thermistors per block, ChargeCurrent at most 4.0 A and OCC1 5.0 A (section 8a's session settings, kept here). Its
path to the node is S-04's as `gen_sch_a.py` generates it: CELL+ over the dock, F1 (25 A MINI), CELL_FUSED, **R17**
(5 mOhm RSR, U3's SRN on CELL_FUSED through R148, SRP on VBAT through R149), VBAT. **No BATFET** (SLUSE66A Figure
10-1, as the generator's comment at U3 says), so the base pack is hard-wired to the system node: that fact shapes the
rest of this page.

## 3. The lid pack's path

### 3a. Protection and gauge: board PL

Board PL is **board P as `gen_sch_p.py` generates it**, a second instance in the lid module: BQ4050 U1 (gauge and
primary protection), BQ7720700 U2 (second level on its own taps, filters, supply and NTC), F1 25 A MINI, F2 Eaton
SCF9550-30-05, Q1/Q2 CSD17570Q5B, R10 2 mOhm, RT1 PTC, JP1, the same J_CELL, J_TS, J_TS2 and J_SMB. A 4S12P block is a
4S block to both levels; the parallel count changes only per-cell currents, which fall. What differs is data only: the
gauge's image at k = 2 (`GAUGE.md`). Its thresholds are in section 4.

### 3b. Charge: a second BQ25731 (U3B), and why one charger cannot serve both packs

**Why a second charger** (authority SESSION; reverse by a battery-selector design if a qualified review prefers one):
1. U3's charge loop regulates the current through ONE sense resistor, R17 (SLUSE66A 9.3.5, page 25: ChargeCurrent is
   the current through RSR). Two packs behind R17 are two packs in parallel: their split would be set by their open-circuit
   voltages and path resistances, not by the charger, exactly the aggregate model's hidden assumption.
2. The charger has no BATFET (Figure 10-1), so it cannot disconnect one pack to charge the other; a selector would need
   two bidirectional switch pairs and a control law of its own, and with the system on VSYS the higher pack would still
   feed the lower one through the selector's discharge side (section 3c).
3. A four-switch buck-boost that is off blocks both directions. SLUSE66A Table 9-3 (page 27) names the four switches;
   `gen_sch_a.py` places U3's N-FETs with Q7's drain on the input side (CH_ACN) and source on CH_SW1, and Q10's drain on
   the output (VBAT) and source on CH_SW2 (the `nfet` line after U3). Each high-side body diode therefore conducts only
   from its switching node toward its own terminal, and the low-side ones only from ground: with the stage off, neither
   terminal can drive current into the other. U3B, placed the same way, isolates the lid from the node except while it
   regulates.
4. U3B's own loops give the lid its own CC-CV charge (16.8 V, 4S strap as U3's R26/R27), its own current (ChargeCurrent
   through R17B) and its own input limit from the node (IIN_HOST through R16B).

**The parts, second issue** (stream s119, 29 September 2026, the session decision of `records/s119/apply_decision_s119.py`:
U3B takes U3's 400 kHz row and the FET pair of decision 57, because REGN cannot drive the first issue's CSD18510Q5B, 120
to 240 mA against its 50 mA minimum limit, SLUSE66A 8.5, printed page 11). Drafts for board A's generator; U3's set
copied:

| Ref | Part or value | Basis |
|---|---|---|
| U3B | BQ25731RSNR | as U3 |
| Q7B | CSD17578Q5A | the buck leg's hard-switched high side (TI SLPS526) |
| Q8B | CSD17577Q5A | the buck leg's synchronous low side (TI SLPS516) |
| Q9B | CSD17578Q5A | the boost leg's hard-switched low side (TI SLPS526) |
| Q10B | CSD17577Q5A | the boost leg's synchronous high side (TI SLPS516) |
| L2B | Coilcraft XAL1010-472ME, 4.7 uH | Coilcraft 804-1 p.1: DCR 5.20 / 5.70 mOhm, Isat 25.4 A, Irms 17.5 A at a 20 C rise; `records/s119/inductor_u3b.out` |
| R_IADPT_B | 191 k 1 percent | SLUSE66A Table 9-4, printed page 27: 4.7 uH at 400 kHz |
| R16B | 10 mOhm 2512 (RAC; RSNS_RAC = 0b) | IIN_HOST clamps at 6.35 A, 9.3.5 and Table 9-1, pages 25 and 26 |
| R17B | 5 mOhm 2512 (RSR; RSNS_RSR = 1b) | as the first issue |
| COMP1_B | 40.2 k, 4.7 nF, 33 pF | Table 9-5's 400 kHz row, pages 27 and 28 |
| COMP2_B | 15 k, 680 pF, 15 pF | Table 9-5's 400 kHz row |

U3's filter set (R146 to R149, C121 10 nF, C122) and input and VSYS capacitors are copied; its VBUS pin is on VBAT (12 to
16.8 V, inside the charger's input operating range VINPUT_OP, 3.5 to 26 V, SLUSE66A 8.5, page 9). With these parts REGN
supplies 10.5 mA typical in buck mode and 32.6 mA at the makers' maxima in buck-boost at 460 kHz
(`records/s117/efficiency.out` section 5). The first issue's parts (CSD18510Q5B x 4, XAL1010-332ME, 169 k, R16B 5 mOhm)
are superseded.

**Settings** (CHARGER.md has the figures): ChargeVoltage 16.8 V (the strap's 4S default); ChargeCurrent at most **7.936 A**
(62 x 128 mA) and never above the lid gauge's ChargingCurrent() x 2 (GAUGE.md); IIN_HOST **6.2 A** nominal from VBAT
(code 124 in 50 mA steps with RAC 10 mOhm, SLUSE66A 9.6.22, page 80; the register text adds 100 mA for the maximum,
6.3 A, under the 6.35 A clamp; second issue, was 8.0 A on 5 mOhm; the model's largest U3B input is 4.08 A,
`records/s119/reconcile_s119.out` section 8); PWM_FREQ at its power-on 1b, 400 kHz (Table 9-8, page 43);
InputVoltage (VINDPM) at 12.0 V so that U3B backs off before it could pull the node below the
base's graceful line (a firmware choice, bounded by the charger's own VINDPM loop).

**The interlock: U3B may run only while U3 reports outside input (CHRG_OK), and never while the lid path is on.** U3B's ILIM_HIZ pin is
pulled below 0.4 V (HiZ, the converter off; above 0.8 V it runs; SLUSE66A pin table page 6 and 9.3.8, pages 26 and 27)
unless BOTH U3's CHRG_OK (open drain, R22 to +3V3: input present and no fault) AND the host's LID_CHG_EN (pulled down,
so a dead host leaves it low) are high. **The default must be off without any logic supply**, because U3B's VBUS is
VBAT and is always present: "the BQ25731 itself does charge without a host, at a 256 mA register default, and its
watchdog does not stop it" (adjudication A02, `records/adj/A02-charger-without-host/`, on TI E2E thread 1316778), which
would move energy from the base into the lid with the kit switched off. So: ILIM_HIZ_B carries TI's
divider from U3B's own VDDA (the pin sets the input limit as 1 V + 40 x IDPM x RAC, SLUSE66A pin table page 6; second
issue: 3.48 V is 6.2 A on 10 mOhm, the same as IIN_HOST, and with EN_EXTILIM at its power-on 1b the lower of the two
applies; VDDA sits at REGN through 10 Ohm, so 3.48 V is within its reach; SLUSE66A prints the pin's accuracy on page 10
for 5 mOhm only); a 2N7002 **Q_E1** holds the pin
at ground with its gate pulled up to U3B's REGN (REGN stays enabled in HiZ, 9.3.8), so U3B sits in HiZ by default; a
second 2N7002 **Q_E2** pulls Q_E1's gate down, released only while an SN74LVC1G08 AND (held,
`v2/vendor/ti/ti-sn74lvc1g08.pdf`) of CHRG_OK and LID_CHG_EN is high. An unpowered gate, a low input or a dead host
leave U3B in HiZ: the SN74LVC1G08's output is high-impedance when unpowered (its Ioff, datasheet 7.3.2), so the
AND output carries its own **100 k pull-down** (R_AND), which holds Q_E2's gate and the UVLO transistor's gate low. An
**open Q_E1** (or an open gate pull-up) is a single fault that lets U3B run from VBAT at its 256 mA power-on default
whenever the logic does not hold it, on battery at night included, with the lid path on: base energy moves to the lid
at about 4 W, bounded by the charger's default and by the lid gauge's charge-temperature and OCC1 windows (section 6).
A host that hangs with LID_CHG_EN high stops talking to the lid gauge, whose host watchdog (HWD,
10 s) then opens the lid's charge FET, and U3's CHRG_OK falls at sunset. With the kit on batteries alone U3's CHRG_OK is low and U3B cannot run, so **the base can never
charge the lid on battery**. The same AND output drives a third 2N7002 that pulls the LM5069's UVLO low (3c):
**whenever U3B may run, the lid's discharge path is off.** Without
it, U3B's output would lift the lid's end of the harness (the charge current through the lead and the cells, about 0.3 V
at 8 A over the cells' 11.7 mOhm and the charge loop's 28 mOhm of `.out` section 0) above the node, and the ideal diode would return U3B's current into VBAT, a
circulating loop that also charges the base outside U3's control. The model never charges and discharges the lid in the
same hour, which this interlock makes true of the circuit.

**The allocation law (host, a firmware draft).** Once a second: **drop LID_CHG_EN whenever U3's input power is below the
load** (U3's ADC: VBUS times the input current, against the load it reports on PSYS), so that in the shoulder hours
(06 and 17 UTC on the reference day: 18.4 and 16.4 W of sun against 42.8 W) the lid path comes back on and the lid
shares the deficit instead of the base carrying it and U3B's draw. While U3B may run: never let U3's battery-current reading
(ADCIBAT, 128 mA steps, SLUSE66A Table 9-7) show the base discharging (lower U3B's ChargeCurrent one step if it does);
otherwise steer U3B's ChargeCurrent, within 0 to 7.936 A and at most 2 x the lid gauge's ChargingCurrent(), so that the
two gauges' RelativeStateOfCharge() stay within 2 percent of each other (raise it while the lid is lower, lower it while
the lid is higher). Equal states of charge are what the model's capacity split produces, and the result does not hang on
the split: charging the base first or the lid first gives the same lowest points (`.out` 4). In daylight the host's
allocation loop (FW row in section 8) holds U3B's charge so that U3's reading of the base's current (ADCIBAT, 128 mA
steps) is not a discharge; a passing cloud lets the base feed U3B for the loop's reaction time, bounded by U3B's
IIN_HOST.

### 3c. Discharge: an ideal diode and a current-limited switch in series, and the join rule

**Parts** (drafts for board A): **U_LD LM74700-Q1** driving **Q_LD CSD18510Q5B** (40 V; RDS(on) 0.79 / 0.96 mOhm at
10 V, TI SLPS632 page 3) as an ideal diode, anode on LID_F (behind F_LA, the node U3B's R17B also feeds), cathode
toward VBAT; then **U_LS LM5069-2** (auto-retry;
SNVS452G, device table on page 3; operating 9 to 80 V, page 1) driving **Q_LS CSD18510Q5B** with **R_LS 5.6 mOhm** 2512
as its sense; the LM5069's input on the ideal diode's cathode side, its output on VBAT. The LM5069's 9 V floor is the
lid at 2.25 V a cell, the second level's under-voltage.

**What each blocks.**
- *Node to lid* (the base charging the lid): the LM74700-Q1 turns its FET off when V(AK) falls below its reverse
  threshold, **-17 / -11 / -2 mV** (SNOSD17G 6.5, page 6), and its fast response "(< 0.75 us)" (page 1); the FET's body
  diode points lid to node, so the reverse current meets a blocking junction. The LM5069's FET is on the node side and its
  body diode points node to lid, but it is in series with the blocked ideal diode. **Base to lid: blocked in hardware, on a fault-free path.**
- *Lid to node*: the ideal diode conducts with its regulated **13 / 20 / 29 mV** V(AK) (page 6) whenever the lid's
  terminal is above the node; the LM5069 limits the current at **VCL 48.5 / 55 / 61.5 mV** over 5.6 mOhm, **8.7 / 9.8 /
  11.0 A** (SNVS452G, page 6), and after its fault timer turns off and retries (the -2 variant). With the LM5069 off,
  its FET's body diode (node to lid) is in series with the ideal diode's (lid to node): **both directions are blocked**.

**Why the limit sits at 8.7 to 11.0 A.** The base pack is hard-wired to VBAT, so a lid whose voltage is above the base's
charges the base through this path. At the limit's maximum, 11.0 A into the base is 1.83 A a cell, **under the 35E's
2.0 A maximum charge current** (spec 3.7), whatever the voltage difference (`.out` 8), on a fault-free path (a shorted
Q_LS, Q7B or Q10B defeats it: section 6). The lid's share of the kit's
10 A continuous (6.7 A at the capacity split) stays under the 8.7 A minimum. At the kit's 18 A peak the lid path limits
and the hard-wired base takes the rest; if the peak lasts past the LM5069's fault timer the lid path turns off and
retries, and the base carries all 18 A meanwhile (3 A a base cell, under the 8 A discharge rating, spec 3.8). The
LM5069's power limit and timer are sized by board A's owner with SNVS452G's design procedure for the start into VBAT's
capacitance with the base absent, the one case in which the lid path, not the base, charges the node.

**Each pack's graceful line.** CONOPS 4c's line (RSOC 5 percent, or the lowest cell at 3.00 V under load) applies per
pack: the host turns the lid path off when the lid reaches it, and shuts the kit down when the base reaches it with the
lid already out. The model's stores end there. With the capacity split the colder lid reaches its line first at the
basis; if the base reached its line first while the lid still held energy, the kit could keep running on both until the
base's own CUV (2.50 V) opens its discharge FET, energy the model does not credit.

**The join rule** (host, a firmware draft): the lid path is enabled while the lid's gauge voltage is at most 0.20 V
above the base's (50 mV a cell); a lid fuller than that waits, disabled, while the base carries the load (the gap closes)
or while U3 charges the base. At 0.20 V the transfer into an unloaded node is at most **2.5 A** (`.out` 8: loops of 41.7
and 39.2 mOhm on the cells' 35 mOhm class figure, an upper bound because the DC resistance is higher), under U3's 4.0 A
setting and the base's OCC1 5.0 A. In service the capacity-proportional allocation (section 6 of `.out`, policy 'ah')
keeps the two packs' states of charge together, so the gap stays small.

**Without the host** (a crash, or the first power-up): the lid path's enable is the LM5069's UVLO/EN pin (threshold
2.45 / 2.5 / 2.55 V, SNVS452G page 5) held by a divider from LID_IN at about 11.0 V rising (the lid itself at 2.75 V a
cell) and pulled low by the host's LID_DSG_OFF through a 2N7002 (default off, so the path defaults ON) or by the
interlock's AND while U3B may run (3b). A default-off
path would leave a full lid unusable when the base is empty and the sensor controller, which runs from the base's node,
is dead; a default-on path joins at any gap, which the 11.0 A limit keeps inside the base cells' charge rating. The
base's own OCC1 (5.0 A, 2 s) then opens the base's charge FET for a gap above about 0.4 V, a recoverable trip. **Taken by
the session: default ON, limited in hardware** (reverse: a default-off enable and a boot path from the lid).

## 4. Every protection threshold, per pack

Base = board P as generated with section 8a's additions; lid = board PL with GAUGE.md's image. Sources: the gauge rows
from `pcb_pack_protection.yaml` and `PRIMARY-CONFIGURATION.md` section 2 (TI SLUUAQ3A sections named there); the second
level from TI SLUSEG7D (Device Comparison Table, 6.5, 6.6); the fuses from Littelfuse 297 (time-current table, 1000 A at
32 VDC) and Eaton ELX1135; the cell limits from Samsung 35E spec Ver. 1.1.

| function | device | base 4S6P | lid 4S12P | cell limit it answers |
|---|---|---|---|---|
| cell over-voltage | gauge COV | 4.25 V, 2 s (recovery 4.10 V) | same | 4.20 V charge (3.2) |
| cell under-voltage | gauge CUV | 2.50 V, 4 s (recovery 3.00 V) | same | 2.30 V over-discharge protection (guideline) |
| charge over-current | gauge OCC1 / OCC2 | 5.0 A, 2 s (section 8a) / TI | **10.0 A, 2 s / 12.0 A** (5,000 / 6,000 internal) | 2.0 A a cell (3.7): 12 A and 24 A |
| discharge over-current | gauge OCD1 / OCD2 | -20 A, 2 s / -24 A, 1 s | same (-10,000 / -12,000 internal) | 8 A a cell (3.8): 48 A and 96 A |
| overload, short circuit | AFE AOLD, ASCD (mV over R10) | 30 A class, 20 ms; about 55.6 or 66.7 A at 183 to 244 us | same codes (true 2 mOhm) | 13 A pulse a cell (3.8) |
| charge temperature | gauge UTC / OTC; T1 to T4 | 1.0 / 44.0 C; 1, 12, 20, 25, 42, 43 C | same | 0 to 45 C (3.12) |
| discharge temperature | gauge UTD / OTD | -9.0 / 57.5 C | same | -10 to 60 C (3.12) |
| second level OV | BQ7720700 COUT to F2 | 4.325 V +-50 mV, 1 s | same (own U2) | as above |
| second level UV | BQ7720700 DOUT holds Q2 | 2.25 V +-50 mV (W4DP-F1 open) | same | 2.30 V |
| second level OT | BQ7720700 | 70 C (62.7 to 77.5 C at its network; BAT-F16 open) | same | 60 C |
| FET over-temperature | PTC RT1 | 110 to 133 C at the element | same | the FETs' 150 C |
| permanent fails | gauge SOT, SUV | 65.0 C; 1.0 V | same | 1.0 V "do not charge" |
| chemical fuse | F2 SCF9550-30-05 | 30 A, 200 % within 60 s, 80 A breaking | same | |
| gross fault | F1 25 A MINI (297) | 27.5 A holds 360,000 s; 33.75 A opens in 0.75 to 600 s; 1000 A at 32 VDC | same | |
| lid path, forward (fault-free) | LM5069-2, 5.6 mOhm | (none: hard-wired) | **8.7 / 9.8 / 11.0 A** | 2.0 A a BASE cell (the join) |
| lid path, reverse | LM74700-Q1 | (none) | **V(AK) -17 / -11 / -2 mV, under 0.75 us** | no charge from the node |
| board A's end of the lid lead | F_LA, 15 A MINI (297) | (none) | holds 16.5 A (110 %) for 360,000 s; 4.58 mOhm, 270 A2s | the harness, for a double fault |
| lid charge | U3B ChargeCurrent, IIN_HOST | (U3: at most 3.968 A) | **at most 7.936 A; 6.2 A in (6.3 A maximum, 6.35 A clamp; second issue)** | 2.0 A a cell |

**The lid's prospective fault** (the method `pcb_energy_chain.yaml` uses for board P): 4 x 35 mOhm / 12 + about 15
mOhm of strip and lead = 26.7 mOhm, 630 A at 16.8 V from the AC impedance (the DC figure is lower); inside F1's 1000 A
at 32 VDC. The base 4S6P by the same method: 4 x 35 / 6 + 15 = 38.3 mOhm, 439 A. ESTIMATE, as the source's is.

## 5. How the host sees two gauges and two chargers

- **Base gauge**: as today, board E's sensor controller U10 on its I2C1 (GPIO2 SMBD, GPIO3 SMBC; FW-E01) at the BQ4050's
  default address 0x16 (8-bit form, SLUUAQ3A 12.1, page 73), broadcasts off (SBS Configuration BCAST = 0; with them on
  the gauge would send to 0x12 and 0x14, page 39).
- **Lid gauge: a separate SMBus segment** (authority SESSION; reason: the lid's SMBus crosses the hinge, and a pinched or
  shorted lead on a shared bus would silence the base gauge too, whose host watchdog, HWD 10 s, then stops the base's
  charge, `PRIMARY-CONFIGURATION.md` section 2). Draft for board E: a second pair of U10's GPIOs as a PIO-driven SMBus at
  100 kHz with the same 100 ohm series and clamp parts as J_SMB, a second JST-XH 1x4 **J_SMB2** in board P's pin order,
  and PRES2 on a third GPIO as PRES is. The lid gauge keeps address 0x16 on its own segment. **If U10 has no three free
  GPIOs** (the board E owner's check): the same segment with the lid gauge at a programmed address (SLUUAQ3A 12.1:
  Address and its two's complement in Address Check), 8-bit 0x1A (7-bit 0x0D) proposed, to be checked against the
  SMBus specification's reserved list (not held in the tree), behind a switch that can isolate the lid segment.
- **Chargers**: U3 and U3B are both BQ25731, whose I2C address is fixed at 0x6B (SLUSE66A Device Comparison Table,
  page 4). U3B therefore sits behind a **TI TCA9543A** 2-channel I2C switch (fetched and filed today,
  `v2/vendor/ti/ti-tca9543a.pdf`, SCPS206B; address 1110 0 A1 A0, 0x70 to 0x73 by its pins, 8.6.1 Figure 14, page 14;
  1.65 to 5.5 V; a RESET input frees a stuck downstream bus) at 0x70 on the kit bus, whose map in the tree shows nothing
  at 0x70 to 0x73 (`gen_sch_a/b/c/e.py`, HW-FW-CONTRACT; a search, not a proof: the bus owner confirms). U3B on channel 0,
  channel 1 spare. The panel controller, which configures U3 today, configures U3B through it.

## 6. Fault cases

Energy results are `.out` section 6 (400 Wp, 200 W stage, entry re-rated, base +20 C, lid at 13.23 C unless stated).

| fault | what the hardware does | who acts next | M1 on the model |
|---|---|---|---|
| **lid pack empty** (a long cold spell, or its protection had been open) | its terminal sits below the node, so the ideal diode passes nothing; the base carries the kit | U3B recharges the lid whenever U3's CHRG_OK is up; the host's join rule | from 06 UTC met; from 18 UTC stops at hour 5 (319.5 Wh unserved) |
| **base pack empty** | the base's gauge has opened its discharge FET at CUV; the lid carries the kit through its path, limited at 8.7 to 11.0 A | the host sheds to keep the load under 8.7 A (FW-C09's shedding); U3 recharges the base (CUV_RECOV_CHG) | from 06 met; from 18 stops at hour 8 |
| **lid cold below 0 C** | the lid gauge's UTC (1.0 C) holds its charge FET open, so U3B delivers nothing (it regulates at 16.8 V into an open FET); the lid discharges until UTD (-9.0 C) on the cells' reduced capacity | the host writes U3B's ChargeCurrent 0 on the gauge's ChargingCurrent() of 0; a lid heater is needed for cold operation (open item, section 9) | at -5 C: stops at hour 21 / 10 |
| **base cold below 0 C** | the base gauge holds its charge FET open; U3's ICHG sees no acceptance | the host writes U3's ChargeCurrent 0; U3B still charges a lid at or above 1 C | not run (the base is inside the closed base, REQ-014's +20 C) |
| **lid protection open** (any FET-opening trip, the second level's DOUT, F2 or F1 open) | the lid path sees no source; the ideal diode blocks the node; U3B regulates into nothing | the host reads the lid gauge's flags; on recovery, the join rule | the base alone (4S6P): stops at hour 16 / 5 (section 8's result) |
| **base protection open** | the lid carries through its limited path | as "base pack empty"; on recovery the base (hard-wired) re-joins: if it returns more than 0.20 V below the lid the host disables the lid path until the gap closes | the lid alone: stops at hour 20 / 8 |
| **short across the hinge harness** (LID+ to LID-) | fed by the lid cells through board PL: the AFE's short-circuit comparator opens Q2 in about 183 to 244 us, F1 (1000 A interrupting) backs it; prospective 630 A (section 4). From the node: the ideal diode blocks within its reverse response; U3B limits and stops on its own system-short protection; F_LA backs a double fault | the host sees both lid-side devices lost; the lid gauge records the trip | as "lid protection open" |
| **SMBus lead to the lid damaged** | its segment is separate: the base gauge is unaffected; the lid gauge's HWD (10 s) opens the lid's charge FET, its discharge stays on | the host drops LID_CHG_EN; the lid discharges on its own protection | lid never recharges: like "U3B off", stops at hour 40 / 28 |
| **U3B off** (the charger stopped) | the lid only discharges | the host reads U3B's status | stops at hour 40 / 28 |
| **Q10B shorted** (U3B's output high-side FET, a SINGLE fault) | lid, SW2, L2B, SW1, then Q7B's body diode into VBAT: the lid feeds the node one diode drop above it, bypassing U_LD and U_LS, so neither the 11.0 A limit nor the interlock applies | bounded only by the lid's OCD1 (-20 A, 2 s) and AFE, and on the base side by the base's OCC1 (5.0 A, 2 s) when the transfer charges the base: **unbounded by the lid path; named for D-09** | not run |
| **Q7B shorted** (U3B's input high-side FET, a SINGLE fault) | VBAT, SW1, L2B, SW2, then Q10B's body diode into the lid: the base charges the lid, bypassing the ideal diode, whenever the node is above the lid by a diode drop | bounded only by the lid's OCC1 (10.0 A true, 2 s), its charge-temperature window and AFE, and by the base's own OCD: **unbounded by the lid path; named for D-09** | not run |
| **Q_LS shorted, or U_LS's gate stuck on** (a SINGLE fault) | removes the 8.7 to 11.0 A limit that the default-ON decision rests on, and defeats the interlock that holds the lid path off while U3B runs, so U3B's output can circulate back into VBAT; a join is then bounded only by the loops (about 59 A at a 4.8 V gap on `.out` 8's 80.9 mOhm, an upper bound), the lid's AFE overload and the base's OCC1 (5.0 A, 2 s) | **named for D-09** with Q_LD, Q7B and Q10B; a bench item: the base's OCC1 opening before the base cells' 2.0 A charge rating is exceeded for longer than its 2 s delay is NOT shown | not run |
| **Q_LD welded** (the ideal diode's FET shorted, a SINGLE fault) | the node can charge the lid through Q_LS's body diode or channel, unlimited by the LM5069 (it senses forward current); the lid's OCC1 (10 A, 2 s) and its AFE stop a gross case | named for the qualified battery review (D-09) | not run |
| **Q_E1 open** (the default-off transistor of U3B's enable, a SINGLE fault) | U3B runs at its 256 mA power-on default whenever the logic does not hold it off, on battery included (3b) | about 4 W from the base to the lid, bounded by the charger's default; the host sees U3B switching when it should not | not run |

## 7. What it asks of board A's entry (the detail is CHARGER.md)

As generated the front end regulates at VSNS **43 / 50 / 57 mV** over R11 10 mOhm (TI SNVSAI1D 6.5, page 7): **4.3 / 5.0
/ 5.7 A** at 20.7 V. **The design case needs at least 5.56 A (115.1 W) into U3, held at the limit's minimum, and 5.81 A
(120.3 W) to keep its 31.1 Wh** (`.out` 5). With U3's IIN_HOST at 4.15 A (4.25 A maximum, under the 4.3 A minimum) it
does not meet M1 at any lid temperature or with 800 Wp; with a typical part (5.0 A) it does not either; only a maximum
part (5.7 A) meets, with 18.6 Wh. With FW-A16 as written (53.9 W) it fails outright. The drafted re-rate (R11 6.2 mOhm,
6.94 A minimum; U3's IIN_HOST 6.2 A, 6.3 A maximum) meets with 31.1 Wh. So Option A(i) needs board A's entry re-rated
as well as board E's stage; the L2, 800 kHz and R16 changes of the first issue are margin choices (CHARGER.md 2).

## 8. Drafts for the generators' owners (nothing here is applied)

- **`gen_sch_a.py`** (board A): the U3B set of 3b; the lid path of 3c (U_LD, Q_LD, U_LS, Q_LS, R_LS, the UVLO divider,
  the LID_DSG_OFF transistor); F_LA 15 A MINI in a Keystone 3568 holder and the lid lead's entry connector J_LID (XT60
  class, as the base lead's on board E); the TCA9543A at 0x70 with its pull-ups and RESET; the AND interlock with Q_E1, Q_E2, the UVLO transistor, the AND output's 100 k pull-down R_AND and LID_CHG_EN's pull-down (3b); the entry
  changes of CHARGER.md. New rails LID_IN (lid lead to F_LA, 16.8 V, 11 A), LID_F (behind F_LA), LID_ID (between the
  ideal diode and the switch), VBUS_B (U3B's input, on VBAT), CHB_ACN, LID_CHG (U3B's output to R17B); every one declared
  with its current for the intent checks.
- **`gen_sch_p.py`**: nothing; board PL is a second instance. The golden image is GAUGE.md's.
- **`gen_sch_e.py`** (board E): J_SMB2, the lid SMBus segment on U10's GPIOs, PRES2 (section 5).
- **`pcb_pack_protection.yaml`** (the integrator's): a `pack_lid` section with GAUGE.md's thresholds and the lid path's
  devices; `pcb_energy_chain.yaml`: the lid stages (cells, board PL, harness, F_LA, U_LD, U_LS, VBAT).
- **`HW-FW-CONTRACT.md`** (the integrator's): FW-A02's lid row (U3B ChargeCurrent at most 2 x the lid gauge's
  ChargingCurrent() and at most 7.936 A; the allocation law); FW-A16 revised for the panel (CHARGER.md); FW-E01's twin
  for the lid segment with the x 2 scaling and the IPSCALE2 check; the join rule and LID_DSG_OFF; LID_CHG_EN; FW-P01's
  lid image.

## 9. Assumptions for the mechanical stream (fnd/a1mech) to reconcile, and open items

- **Board PL** is board P's outline (44 x 70 mm as generated; its four-layer regeneration O-11 may change it), mounted in
  the lid module beside the 48 cells with J_CELL, J_TS, J_TS2 and J_SMB as board P's.
- **The hinge harness**: two 12 AWG silicone power conductors (LID+, LID-), one 4-way SMBus lead (board P's JST-XH, 26
  AWG), and a heater pair if the lid gets a heater; **0.6 m each way assumed** (the energy model's loop resistance and
  the join-current bound use it; a longer lead raises the loss and lowers the join current); carries at most 11.0 A
  discharging and 7.936 A charging. Its bend at the hinge, strain relief and flex life are mechanical items.
- **Board A area** for U3B's set, the lid path, F_LA, J_LID, the TCA9543A and the interlock: about 40 x 45 mm (ESTIMATE:
  QFN-32, six 5 x 6 mm FETs, a 10 x 10 mm inductor, three 2512 shunts, a MINI holder, an XT60, small logic). If board A
  has no room, a small daughter board on VBAT near the hinge carries the same circuit (its VBAT feed then carries up to 11
  A out and 6.3 A in; second issue, was 8.2 A).
- **Standby drain of the lid path** (check item M9): the LM5069 draws 1.3 / 1.6 mA enabled (SNVS452G page 5, IIN-EN)
  and the LM74700-Q1 80 / 130 uA (SNOSD17G 6.5) from the lid, whose path is default on: 1.38 to 1.73 mA, **1.0 to 1.25
  Ah a month** (2.5 to 3.1 percent of 40.2 Ah; ESTIMATE, the makers' typical and maximum), plus U3B in HiZ from VBAT (its
  HiZ quiescent current not read here). For storage the lid gauge's SHUTDOWN (FW-E09's MAC command) opens its FETs and
  removes this drain; LID_DSG_OFF alone does not (the disabled LM5069 still draws 480 / 650 uA, IIN-DIS, page 5).
- **Open**: a heater for the lid pack (the charge window starts at 1 C at the gauge); the lid's temperature under sun
  (the shade rule); the qualified battery review of the whole two-pack design (D-09), including the double faults of
  section 6; TI's answers Q-TI-A1 and Q-TI-A2 (GAUGE.md).
