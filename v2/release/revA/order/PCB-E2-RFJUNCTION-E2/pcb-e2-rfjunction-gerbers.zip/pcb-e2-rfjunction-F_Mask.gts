G04 #@! TF.GenerationSoftware,KiCad,Pcbnew,9.0.9-9.0.9~ubuntu24.04.1*
G04 #@! TF.CreationDate,2026-09-03T17:43:21+02:00*
G04 #@! TF.ProjectId,pcb-e2-rfjunction,7063622d-6532-42d7-9266-6a756e637469,A (E2)*
G04 #@! TF.SameCoordinates,Original*
G04 #@! TF.FileFunction,Soldermask,Top*
G04 #@! TF.FilePolarity,Negative*
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 9.0.9-9.0.9~ubuntu24.04.1) date 2026-09-03 17:43:21*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
%ADD10C,3.200000*%
G04 APERTURE END LIST*
D10*
G04 #@! TO.C,H5*
X133300000Y4000000D03*
G04 #@! TD*
G04 #@! TO.C,H3*
X-8600000Y4000000D03*
G04 #@! TD*
G04 #@! TO.C,H4*
X8600000Y4000000D03*
G04 #@! TD*
G04 #@! TO.C,H6*
X152400000Y4000000D03*
G04 #@! TD*
G04 #@! TO.C,H2*
X-133300001Y4000000D03*
G04 #@! TD*
G04 #@! TO.C,H1*
X-152400001Y4000000D03*
G04 #@! TD*
M02*
