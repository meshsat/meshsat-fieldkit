G04 #@! TF.GenerationSoftware,KiCad,Pcbnew,9.0.9-9.0.9~ubuntu24.04.1*
G04 #@! TF.CreationDate,2026-09-03T17:43:24+02:00*
G04 #@! TF.ProjectId,pcb-c-ring,7063622d-632d-4726-996e-672e6b696361,A (R1)*
G04 #@! TF.SameCoordinates,Original*
G04 #@! TF.FileFunction,Soldermask,Top*
G04 #@! TF.FilePolarity,Negative*
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 9.0.9-9.0.9~ubuntu24.04.1) date 2026-09-03 17:43:24*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
%ADD10C,3.200000*%
G04 APERTURE END LIST*
D10*
G04 #@! TO.C,H1*
X-50095001Y-24099999D03*
G04 #@! TD*
G04 #@! TO.C,H3*
X-50095001Y24100000D03*
G04 #@! TD*
G04 #@! TO.C,H4*
X50095000Y24100000D03*
G04 #@! TD*
G04 #@! TO.C,H2*
X50095000Y-24099999D03*
G04 #@! TD*
M02*
